package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "social_accounts")
data class SocialAccountEntity(
    @PrimaryKey
    val platform: String, // YouTube, TikTok, Facebook, Instagram, Threads, Pinterest, X
    val accountHandle: String,
    val isConnected: Boolean,
    val autoPublish: Boolean = true,
    val followerCount: String = "0",
    val reachCount: String = "0",
    val engagementRate: String = "0%",
    val recentPostsCount: Int = 0,
    val status: String = "Active",
    val lastSyncTime: Long = System.currentTimeMillis()
)
