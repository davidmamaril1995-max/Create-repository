package com.example.ui.screens.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.ProjectEntity
import com.example.ui.theme.*
import com.example.ui.viewmodels.FacelessViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(
    viewModel: FacelessViewModel
) {
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    var viewMode by remember { mutableStateOf("Monthly") } // Daily, Weekly, Monthly
    var selectedDate by remember { mutableStateOf("2026-07-25") }
    var selectedProjectForEditSchedule by remember { mutableStateOf<ProjectEntity?>(null) }
    var actionMessage by remember { mutableStateOf("") }

    val scheduledProjects = projects.filter { it.status.equals("Scheduled", ignoreCase = true) }
    val publishedProjects = projects.filter { it.status.equals("Published", ignoreCase = true) }
    val draftProjects = projects.filter { it.status.equals("Draft", ignoreCase = true) || it.status.equals("Ready", ignoreCase = true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = CosmicCyan, modifier = Modifier.size(24.dp))
                        Text(
                            text = "Galactic Content Calendar",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBackground)
            )
        },
        containerColor = StudioDarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // View Mode Selector (Daily, Weekly, Monthly)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Daily", "Weekly", "Monthly").forEach { mode ->
                        val isSelected = viewMode == mode
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewMode = mode },
                            label = { Text(mode, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PurpleContainer,
                                selectedLabelColor = OnPurpleContainer
                            )
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = StudioDarkSurface
                ) {
                    Text("July 2026", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CosmicCyan, modifier = Modifier.padding(8.dp))
                }
            }

            // Calendar Visual Grid Representation
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Orbit Broadcast Schedule ($viewMode View)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NebulaPurple)
                    HorizontalDivider(color = StudioBorder)

                    // Calendar Matrix / Grid Representation
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach { day ->
                            Text(day, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        (20..26).forEach { dateNum ->
                            val isSelectedDate = dateNum == 25
                            val hasPosts = dateNum in listOf(22, 25, 26)
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(
                                        if (isSelectedDate) CosmicCyan else if (hasPosts) PurpleContainer else StudioDarkSurfaceVariant,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { selectedDate = "2026-07-$dateNum" },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = dateNum.toString(),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelectedDate) StudioDarkBackground else TextPrimary
                                    )
                                    if (hasPosts && !isSelectedDate) {
                                        Box(
                                            modifier = Modifier
                                                .size(4.dp)
                                                .background(StarGold, RoundedCornerShape(2.dp))
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Category Sections (Scheduled, Published, Drafts)
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                item {
                    Text("Scheduled Missions (${scheduledProjects.size})", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = StarGold)
                }

                if (scheduledProjects.isEmpty()) {
                    item {
                        Text("No missions scheduled for $selectedDate.", fontSize = 12.sp, color = TextMuted)
                    }
                } else {
                    items(scheduledProjects) { project ->
                        ScheduledProjectCard(
                            project = project,
                            onEditSchedule = { selectedProjectForEditSchedule = project },
                            onDeleteSchedule = {
                                viewModel.deleteProject(project.id)
                                actionMessage = "Deleted schedule for ${project.title}"
                            }
                        )
                    }
                }

                item {
                    Text("Published History (${publishedProjects.size})", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = StatusGreen)
                }

                items(publishedProjects) { project ->
                    PublishedProjectCard(project = project)
                }

                item {
                    Text("Drafts & Ready Queue (${draftProjects.size})", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                }

                items(draftProjects) { project ->
                    DraftProjectCard(
                        project = project,
                        onScheduleNow = {
                            selectedProjectForEditSchedule = project
                        }
                    )
                }

                item { Spacer(modifier = Modifier.height(20.dp)) }
            }
        }
    }

    // Edit Schedule Modal Dialog
    selectedProjectForEditSchedule?.let { project ->
        EditScheduleDialog(
            project = project,
            onDismiss = { selectedProjectForEditSchedule = null },
            onSaveSchedule = { newDate, newTime ->
                val updated = project.copy(
                    status = "Scheduled",
                    scheduledTime = System.currentTimeMillis() + 172800000L
                )
                viewModel.updateProject(updated)
                actionMessage = "Updated schedule for ${project.title} to $newDate at $newTime"
                selectedProjectForEditSchedule = null
            }
        )
    }
}

@Composable
private fun ScheduledProjectCard(
    project: ProjectEntity,
    onEditSchedule: () -> Unit,
    onDeleteSchedule: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("scheduled_card_${project.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StarGold)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(project.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("Channels: ${project.targetPlatforms}", fontSize = 11.sp, color = CosmicCyan)
                Text("Scheduled: ${SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date(if (project.scheduledTime > 0) project.scheduledTime else System.currentTimeMillis() + 86400000L))}", fontSize = 10.sp, color = StarGold)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onEditSchedule) {
                    Icon(Icons.Default.EditCalendar, contentDescription = "Edit Schedule", tint = CosmicCyan)
                }
                IconButton(onClick = onDeleteSchedule) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete Schedule", tint = StatusRed)
                }
            }
        }
    }
}

@Composable
private fun PublishedProjectCard(project: ProjectEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(project.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("Published • ${project.targetPlatforms}", fontSize = 11.sp, color = StatusGreen)
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = StatusGreen.copy(alpha = 0.2f)
            ) {
                Text("✓ Live", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = StatusGreen, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
            }
        }
    }
}

@Composable
private fun DraftProjectCard(
    project: ProjectEntity,
    onScheduleNow: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(project.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("${project.nicheCategory} • ${project.status}", fontSize = 11.sp, color = TextMuted)
            }

            Button(
                onClick = onScheduleNow,
                colors = ButtonDefaults.buttonColors(containerColor = PurpleContainer)
            ) {
                Text("Schedule", color = OnPurpleContainer, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun EditScheduleDialog(
    project: ProjectEntity,
    onDismiss: () -> Unit,
    onSaveSchedule: (String, String) -> Unit
) {
    var dateInput by remember { mutableStateOf("2026-07-28") }
    var timeInput by remember { mutableStateOf("19:30") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reschedule Mission Broadcast", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(project.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CosmicCyan)
                OutlinedTextField(
                    value = dateInput,
                    onValueChange = { dateInput = it },
                    label = { Text("Broadcast Date") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = timeInput,
                    onValueChange = { timeInput = it },
                    label = { Text("Broadcast Time") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSaveSchedule(dateInput, timeInput) },
                colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan)
            ) {
                Text("Save Schedule", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        },
        containerColor = StudioDarkSurface
    )
}
