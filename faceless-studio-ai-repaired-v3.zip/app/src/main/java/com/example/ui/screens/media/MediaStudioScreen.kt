package com.example.ui.screens.media

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

/**
 * Resolves the display name of a content Uri via the ContentResolver, falling back
 * to the last path segment when the provider does not expose OpenableColumns.
 */
private fun resolveFileName(context: android.content.Context, uri: Uri): String {
    var name: String? = null
    try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIndex >= 0 && cursor.moveToFirst()) {
                name = cursor.getString(nameIndex)
            }
        }
    } catch (e: Exception) {
        // Fall through to the Uri's last path segment below.
    }
    return name ?: uri.lastPathSegment ?: "selected_file"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaStudioScreen(
    onRecreateDone: () -> Unit = {}
) {
    val context = LocalContext.current
    var selectedMediaType by remember { mutableStateOf("Video") } // "Image" or "Video"
    var uploadedUri by remember { mutableStateOf<Uri?>(null) }
    var uploadedFileName by remember { mutableStateOf<String?>(null) }
    var processingOperation by remember { mutableStateOf<String?>(null) }
    var operationResultMessage by remember { mutableStateOf("") }
    var selectedRecreateFormat by remember { mutableStateOf("Shorts (9:16)") }

    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            uploadedUri = uri
            uploadedFileName = resolveFileName(context, uri)
            operationResultMessage = ""
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.PermMedia, contentDescription = null, tint = CosmicCyan, modifier = Modifier.size(24.dp))
                        Text(
                            text = "Media Studio & AI Recreate",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBackground)
            )
        },
        containerColor = StudioDarkBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Upload Drop Area & Type Selector
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("1. Upload Source Asset", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = NebulaPurple)

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            listOf("Video", "Image").forEach { type ->
                                val isSelected = selectedMediaType == type
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        if (selectedMediaType != type) {
                                            selectedMediaType = type
                                            uploadedUri = null
                                            uploadedFileName = null
                                            operationResultMessage = ""
                                        }
                                    },
                                    label = { Text(type, fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = PurpleContainer,
                                        selectedLabelColor = OnPurpleContainer
                                    )
                                )
                            }
                        }

                        // Drag Drop Area
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.verticalGradient(listOf(StudioDarkSurfaceVariant, StudioDarkSurface))
                                )
                                .border(1.5.dp, Brush.horizontalGradient(listOf(CosmicCyan, NebulaPurple)), RoundedCornerShape(16.dp))
                                .clickable {
                                    val mimeType = if (selectedMediaType == "Video") "video/*" else "image/*"
                                    mediaPickerLauncher.launch(mimeType)
                                }
                                .testTag("upload_media_box"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (selectedMediaType == "Video") Icons.Default.CloudUpload else Icons.Default.AddPhotoAlternate,
                                    contentDescription = null,
                                    tint = CosmicCyan,
                                    modifier = Modifier.size(40.dp)
                                )
                                Text(
                                    text = if (uploadedFileName != null) "✓ Loaded: $uploadedFileName" else "Tap to Select or Drop $selectedMediaType File",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (uploadedFileName != null) StatusGreen else TextPrimary
                                )
                                Text("Supports MP4, MOV, PNG, JPG, WEBP up to 2GB", fontSize = 10.sp, color = TextMuted)
                            }
                        }
                    }
                }
            }

            // Image Operations (If Image selected)
            if (selectedMediaType == "Image") {
                item {
                    StudioCard(title = "Image Processing Toolkit") {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Perform instant non-destructive transformations:", fontSize = 12.sp, color = TextSecondary)

                            val imageTools = listOf(
                                "Enhance AI Quality" to Icons.Default.AutoFixHigh,
                                "Smart Resize" to Icons.Default.AspectRatio,
                                "Crop & Focus" to Icons.Default.Crop,
                                "Convert Format" to Icons.Default.Transform,
                                "Generate Thumbnail" to Icons.Default.Image
                            )

                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(imageTools) { (toolName, icon) ->
                                    Button(
                                        onClick = {
                                            processingOperation = toolName
                                            operationResultMessage = if (uploadedUri != null) {
                                                "✓ Successfully performed '$toolName' on $uploadedFileName!"
                                            } else {
                                                "⚠ Upload an image first before running '$toolName'."
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = StudioDarkSurfaceVariant)
                                    ) {
                                        Icon(icon, contentDescription = null, tint = CosmicCyan, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(toolName, color = TextPrimary, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Video Operations (If Video selected)
            if (selectedMediaType == "Video") {
                item {
                    StudioCard(title = "Video Processing Toolkit") {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Perform video timeline surgery:", fontSize = 12.sp, color = TextSecondary)

                            val videoTools = listOf(
                                "Trim Clip" to Icons.Default.ContentCut,
                                "Split Scene" to Icons.Default.CallSplit,
                                "Merge Clips" to Icons.Default.MergeType,
                                "Crop Frame" to Icons.Default.Crop,
                                "Extract Audio" to Icons.Default.GraphicEq,
                                "Replace Audio" to Icons.Default.MusicNote,
                                "Generate Captions" to Icons.Default.ClosedCaption,
                                "Generate Subtitles" to Icons.Default.Subtitles
                            )

                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(videoTools) { (toolName, icon) ->
                                    Button(
                                        onClick = {
                                            processingOperation = toolName
                                            operationResultMessage = if (uploadedUri != null) {
                                                "✓ Applied '$toolName' to $uploadedFileName successfully!"
                                            } else {
                                                "⚠ Upload a video first before running '$toolName'."
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = StudioDarkSurfaceVariant)
                                    ) {
                                        Icon(icon, contentDescription = null, tint = CosmicCyan, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(toolName, color = TextPrimary, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // AI Recreation Mode
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, CosmicCyan)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = StarGold)
                                Text("AI Recreation Engine", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }

                            Text(
                                "Upload a video and automatically repurpose it into high-converting platform formats:",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )

                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(
                                    listOf(
                                        "Shorts (9:16)",
                                        "TikTok (9:16)",
                                        "Reels (9:16)",
                                        "Square (1:1)",
                                        "Landscape (16:9)",
                                        "AI Remix Mode"
                                    )
                                ) { fmt ->
                                    val isSelected = selectedRecreateFormat == fmt
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { selectedRecreateFormat = fmt },
                                        label = { Text(fmt) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = GoldContainer,
                                            selectedLabelColor = OnGoldContainer
                                        )
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    if (uploadedUri != null) {
                                        operationResultMessage = "✓ AI Recreated new $selectedRecreateFormat video asset from $uploadedFileName with auto-captions and voice synthesis!"
                                        onRecreateDone()
                                    } else {
                                        operationResultMessage = "⚠ Upload a video first before running AI Recreate."
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("ai_recreate_submit_btn"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan)
                            ) {
                                Icon(Icons.Default.AutoMode, contentDescription = null, tint = StudioDarkBackground)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Recreate To $selectedRecreateFormat", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            if (operationResultMessage.isNotEmpty()) {
                item {
                    val isWarning = operationResultMessage.startsWith("⚠")
                    val statusColor = if (isWarning) StatusRed else StatusGreen
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = statusColor.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, statusColor)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                if (isWarning) Icons.Default.WarningAmber else Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = statusColor
                            )
                            Text(operationResultMessage, fontSize = 12.sp, color = statusColor, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun StudioCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = NebulaPurple)
            HorizontalDivider(color = StudioBorder)
            content()
        }
    }
}
