package com.example.data.repository

import com.example.data.local.*
import com.example.data.remote.GeminiNetworkClient
import com.example.data.remote.SocialPublishService
import com.example.data.remote.PublishResult
import kotlinx.coroutines.flow.Flow

class FacelessRepository(private val db: AppDatabase) {

    private val projectDao = db.projectDao()
    private val trendDao = db.trendDao()
    private val socialDao = db.socialAccountDao()

    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()
    val archivedProjects: Flow<List<ProjectEntity>> = projectDao.getArchivedProjects()
    val favoriteProjects: Flow<List<ProjectEntity>> = projectDao.getFavoriteProjects()
    val allTrends: Flow<List<TrendTopicEntity>> = trendDao.getAllTrends()
    val allSocialAccounts: Flow<List<SocialAccountEntity>> = socialDao.getAllAccounts()
    val projectCount: Flow<Int> = projectDao.getProjectCount()
    val totalViews: Flow<Long?> = projectDao.getTotalViews()

    fun getProjectsByStatus(status: String): Flow<List<ProjectEntity>> =
        projectDao.getProjectsByStatus(status)

    fun getTrendsByCategory(category: String): Flow<List<TrendTopicEntity>> =
        trendDao.getTrendsByCategory(category)

    suspend fun getProjectById(id: Long): ProjectEntity? = projectDao.getProjectById(id)

    suspend fun saveProject(project: ProjectEntity): Long = projectDao.insertProject(project)

    suspend fun updateProject(project: ProjectEntity) = projectDao.updateProject(project)

    suspend fun deleteProject(id: Long) = projectDao.deleteProjectById(id)

    suspend fun toggleFavorite(id: Long, isFavorite: Boolean) = projectDao.updateFavoriteStatus(id, isFavorite)

    suspend fun toggleArchive(id: Long, isArchived: Boolean) = projectDao.updateArchiveStatus(id, isArchived)

    suspend fun updateOrganization(id: Long, workspace: String, folder: String, campaign: String) =
        projectDao.updateOrganization(id, workspace, folder, campaign)

    suspend fun toggleTrendSave(id: Long, isSaved: Boolean) = trendDao.updateSaveStatus(id, isSaved)

    suspend fun updateSocialConnection(platform: String, isConnected: Boolean) =
        socialDao.updateConnectionStatusForPlatform(platform, isConnected)

    suspend fun updateOAuthTokens(platform: String, isConnected: Boolean, handle: String, token: String, refreshToken: String, expiry: Long) =
        socialDao.updateOAuthTokens(platform, isConnected, handle, token, refreshToken, expiry, System.currentTimeMillis())

    suspend fun generateScriptWithAI(topic: String, niche: String, format: String): String {
        val systemPrompt = "You are an expert viral faceless content scriptwriter. Generate 3 compelling hooks, a high-pacing 60-second video body script, and a high-conversion Call To Action for vertical short video formats."
        val prompt = "Create a viral video script for a faceless video about '$topic' in the '$niche' category formatted for $format ratio."
        return GeminiNetworkClient.generateText(prompt, systemPrompt)
    }

    suspend fun generateTitlesWithAI(topic: String): List<String> {
        val prompt = "Generate 5 ultra-viral click-worthy titles for a video about '$topic'."
        val text = GeminiNetworkClient.generateText(prompt)
        return text.lines().filter { it.isNotBlank() }.take(5)
    }

    suspend fun generateHashtagsWithAI(topic: String): String {
        val prompt = "Generate 10 trending hashtags for a video about '$topic'."
        return GeminiNetworkClient.generateText(prompt)
    }

    suspend fun discoverNewTrends(category: String): List<TrendTopicEntity> {
        val defaultTrends = listOf(
            TrendTopicEntity(
                topicTitle = "Quantum Computing Breakthroughs 2026",
                category = "Tech & AI",
                score = 98,
                summary = "New topological qubits promise instant decryption. High viral interest among tech enthusiasts.",
                targetAudience = "Gen Z Techies, Developers, Engineers",
                recommendedPlatforms = "YouTube, TikTok, Threads",
                searchVolume = "1.8M/mo"
            ),
            TrendTopicEntity(
                topicTitle = "The 50/30/20 Passive Income AI Bot Hack",
                category = "Personal Finance",
                score = 95,
                summary = "Automated micro-investing scripts and faceless channel monetization strategies.",
                targetAudience = "Side Hustlers, College Students, Investors",
                recommendedPlatforms = "TikTok, Instagram, YouTube",
                searchVolume = "2.4M/mo"
            ),
            TrendTopicEntity(
                topicTitle = "Ancient Submarine Ruins Found in Mariana Trench",
                category = "Horror & Mystery",
                score = 92,
                summary = "Unexplained ocean acoustics recorded at 11,000 meters depth.",
                targetAudience = "Conspiracy Buffs, Mystery Fans, Sci-Fi Lovers",
                recommendedPlatforms = "YouTube Shorts, TikTok, Pinterest",
                searchVolume = "950K/mo"
            ),
            TrendTopicEntity(
                topicTitle = "Mars Colony Cyberpunk Architecture Concepts",
                category = "Sci-Fi & Space",
                score = 89,
                summary = "Biomorphic habitats designed for extreme Martian dust storms.",
                targetAudience = "Futurists, Designers, Space Geeks",
                recommendedPlatforms = "Pinterest, Instagram, Threads",
                searchVolume = "1.1M/mo"
            ),
            TrendTopicEntity(
                topicTitle = "3 Secret Smartphone Settings to 10x Battery Life",
                category = "Life Hacks",
                score = 96,
                summary = "Hidden developer menu toggles that eliminate background battery drain.",
                targetAudience = "Everyday Phone Users, Tech Beginners",
                recommendedPlatforms = "TikTok, Facebook, YouTube, X",
                searchVolume = "3.2M/mo"
            )
        )

        trendDao.insertTrends(defaultTrends)
        return defaultTrends
    }

    suspend fun seedInitialDataIfEmpty() {
        // Seed Social Accounts (All 7 required platforms)
        val initialAccounts = listOf(
            SocialAccountEntity(platform = "YouTube", accountName = "Intergalactic Studio Main", accountHandle = "@IntergalacticStudio", isConnected = true, isActiveTarget = true, followerCount = "124.8K", reachCount = "850K", engagementRate = "9.4%", recentPostsCount = 42),
            SocialAccountEntity(platform = "TikTok", accountName = "Intergalactic AI Official", accountHandle = "@intergalactic_ai", isConnected = true, isActiveTarget = true, followerCount = "312.5K", reachCount = "2.1M", engagementRate = "14.2%", recentPostsCount = 89),
            SocialAccountEntity(platform = "Facebook", accountName = "Intergalactic Page", accountHandle = "Intergalactic Studio Page", isConnected = true, isActiveTarget = true, followerCount = "88.4K", reachCount = "420K", engagementRate = "6.8%", recentPostsCount = 31),
            SocialAccountEntity(platform = "Instagram", accountName = "Intergalactic Reels", accountHandle = "@intergalactic_reels", isConnected = true, isActiveTarget = true, followerCount = "210.4K", reachCount = "1.4M", engagementRate = "11.1%", recentPostsCount = 65),
            SocialAccountEntity(platform = "Threads", accountName = "Intergalactic Threads", accountHandle = "@intergalactic_ai", isConnected = true, isActiveTarget = true, followerCount = "45.2K", reachCount = "180K", engagementRate = "8.5%", recentPostsCount = 24),
            SocialAccountEntity(platform = "Pinterest", accountName = "Intergalactic Pins", accountHandle = "@intergalactic_pins", isConnected = true, isActiveTarget = true, followerCount = "88.1K", reachCount = "610K", engagementRate = "7.3%", recentPostsCount = 53),
            SocialAccountEntity(platform = "X", accountName = "Intergalactic X Channel", accountHandle = "@IntergalacticAI", isConnected = true, isActiveTarget = true, followerCount = "156.3K", reachCount = "920K", engagementRate = "10.5%", recentPostsCount = 78)
        )
        socialDao.insertAccounts(initialAccounts)

        // Seed Sample Projects across Workspaces, Folders, Campaigns
        val sampleProjects = listOf(
            ProjectEntity(
                title = "10 Secret AI Tools That Feel Illegal to Know",
                nicheCategory = "Tech & AI",
                hookText = "Stop paying for software! These 3 secret AI tools do everything for free.",
                scriptBody = "Tool number one generates complete presentation decks in 10 seconds. Tool number two cleans ambient noise from any mic recording instantly. Tool number three turns raw text into realistic 3D animations.",
                ctaText = "Hit follow for daily secret AI tool discoveries!",
                voiceoverStyle = "Deep Space Cinematic",
                videoFormat = "9:16",
                visualStyle = "Cyberpunk 3D",
                status = "Published",
                targetPlatforms = "YouTube,TikTok,Instagram,Facebook,Threads,Pinterest,X",
                viewsCount = 482900L,
                engagementRate = 8.4f,
                contentType = "Short Video",
                durationSeconds = 45,
                isFavorite = true,
                workspace = "Main Workspace",
                folder = "Tech Viral",
                campaign = "Q3 Product Launch"
            ),
            ProjectEntity(
                title = "The Terrifying Ocean Sound Recorded at 11,000m Depth",
                nicheCategory = "Horror & Mystery",
                hookText = "In 1997, NOAA hydrophones captured a sound so loud it was heard 3,000 miles away...",
                scriptBody = "Scientists named it 'The Bloop'. It was organic in origin, but far larger than any known marine mammal on Earth. What lurks in the abyss?",
                ctaText = "Subscribe if you dare to explore deep sea mysteries!",
                voiceoverStyle = "Dark Nebula",
                videoFormat = "9:16",
                visualStyle = "Photorealistic Space",
                status = "Published",
                targetPlatforms = "YouTube,TikTok,Pinterest,X",
                viewsCount = 921400L,
                engagementRate = 12.1f,
                contentType = "Reel",
                durationSeconds = 58,
                isFavorite = true,
                workspace = "Main Workspace",
                folder = "Cosmic Horror",
                campaign = "Abyss Series"
            ),
            ProjectEntity(
                title = "How 19-Year-Olds Are Making $10k/Mo With Intergalactic Channels",
                nicheCategory = "Personal Finance",
                hookText = "You don't need a camera or your face to build a 6-figure social media empire in 2026.",
                scriptBody = "Step 1: Pick a high-CPM niche like Finance or Tech. Step 2: Use AI to auto-discover trending signals. Step 3: Schedule auto-posts across 7 social platforms.",
                ctaText = "Comment 'START' to get our free automation guide!",
                voiceoverStyle = "Quantum Storyteller",
                videoFormat = "9:16",
                visualStyle = "Minimalist Vector",
                status = "Scheduled",
                targetPlatforms = "YouTube,TikTok,Threads,Instagram,Facebook,X",
                scheduledTime = System.currentTimeMillis() + 86400000L,
                viewsCount = 0L,
                engagementRate = 0f,
                contentType = "Short Video",
                durationSeconds = 40,
                isFavorite = false,
                workspace = "Creator Hub",
                folder = "Monetization",
                campaign = "Side Hustle 2026"
            )
        )

        for (p in sampleProjects) {
            projectDao.insertProject(p)
        }

        discoverNewTrends("Tech & AI")
    }

    suspend fun publishProject(project: ProjectEntity): List<PublishResult> {
        val platforms = project.targetPlatforms.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val results = SocialPublishService.publishContent(
            platforms = platforms,
            title = project.title,
            scriptBody = project.scriptBody,
            thumbnailUri = project.thumbnailUri
        )
        val updatedProject = project.copy(
            status = "Published",
            updatedAt = System.currentTimeMillis()
        )
        projectDao.updateProject(updatedProject)
        return results
    }
}
