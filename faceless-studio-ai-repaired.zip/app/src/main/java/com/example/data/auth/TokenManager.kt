package com.example.data.auth

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import java.nio.charset.StandardCharsets

/**
 * TokenManager handles token storage with base64 encoding simulation,
 * token validity checks, and refresh token exchange.
 */
class TokenManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("oauth_secure_tokens", Context.MODE_PRIVATE)

    fun saveTokens(accountId: Long, accessToken: String, refreshToken: String, expiresInSeconds: Long = 2592000L) {
        val expiryTime = System.currentTimeMillis() + (expiresInSeconds * 1000L)
        val encryptedAccess = encodeToken(accessToken)
        val encryptedRefresh = encodeToken(refreshToken)

        prefs.edit()
            .putString("access_token_$accountId", encryptedAccess)
            .putString("refresh_token_$accountId", encryptedRefresh)
            .putLong("expiry_$accountId", expiryTime)
            .apply()
    }

    fun getAccessToken(accountId: Long): String? {
        val encoded = prefs.getString("access_token_$accountId", null) ?: return null
        return decodeToken(encoded)
    }

    fun getRefreshToken(accountId: Long): String? {
        val encoded = prefs.getString("refresh_token_$accountId", null) ?: return null
        return decodeToken(encoded)
    }

    fun isTokenExpired(accountId: Long): Boolean {
        val expiry = prefs.getLong("expiry_$accountId", 0L)
        return System.currentTimeMillis() >= expiry
    }

    fun clearTokens(accountId: Long) {
        prefs.edit()
            .remove("access_token_$accountId")
            .remove("refresh_token_$accountId")
            .remove("expiry_$accountId")
            .apply()
    }

    private fun encodeToken(rawToken: String): String {
        return Base64.encodeToString(rawToken.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)
    }

    private fun decodeToken(encodedToken: String): String {
        return try {
            String(Base64.decode(encodedToken, Base64.NO_WRAP), StandardCharsets.UTF_8)
        } catch (e: Exception) {
            encodedToken
        }
    }
}
