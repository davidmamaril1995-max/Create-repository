package com.example.ui.screens.social

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.SocialAccountEntity
import com.example.ui.theme.*
import com.example.ui.viewmodels.FacelessViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialCommandScreen(
    viewModel: FacelessViewModel
) {
    val socialAccounts by viewModel.socialAccounts.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Command Center, 1 = Accounts, 2 = Bulk Publishing, 3 = Social Inbox
    var selectedInboxFilter by remember { mutableStateOf("All") } // All, Comments, Messages, System Alerts
    var replyText by remember { mutableStateOf("") }
    var actionStatusMessage by remember { mutableStateOf("") }

    val allPlatforms = listOf("YouTube", "TikTok", "Facebook", "Instagram", "Threads", "Pinterest", "X")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Hub, contentDescription = null, tint = CosmicCyan, modifier = Modifier.size(24.dp))
                        Text(
                            text = "Social Command Center",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBackground)
            )
        },
        containerColor = StudioDarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Main Section Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = StudioDarkSurface,
                contentColor = CosmicCyan,
                divider = { HorizontalDivider(color = StudioBorder) }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Dashboard", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Accounts (7)", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Bulk Publish", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Inbox (14)", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }

            // Tab Content Router
            when (selectedTab) {
                0 -> DashboardSection(socialAccounts = socialAccounts)
                1 -> AccountsManagementSection(
                    allPlatforms = allPlatforms,
                    connectedAccounts = socialAccounts,
                    onToggleConnection = { viewModel.toggleSocialConnection(it) },
                    onSaveOAuth = { platform, handle, token, refreshToken ->
                        viewModel.saveOAuthConnection(platform, handle, token, refreshToken)
                    }
                )
                2 -> BulkPublishingSection(
                    connectedAccounts = socialAccounts,
                    onPublishTriggered = { msg -> actionStatusMessage = msg }
                )
                3 -> SocialInboxSection(
                    selectedFilter = selectedInboxFilter,
                    onFilterChange = { selectedInboxFilter = it },
                    replyText = replyText,
                    onReplyTextChange = { replyText = it },
                    onSendReply = {
                        actionStatusMessage = "Reply sent successfully across transmitter channel!"
                        replyText = ""
                    }
                )
            }

            if (actionStatusMessage.isNotEmpty()) {
                Snackbar(
                    action = {
                        TextButton(onClick = { actionStatusMessage = "" }) {
                            Text("OK", color = CosmicCyan)
                        }
                    },
                    containerColor = StudioDarkSurface
                ) {
                    Text(actionStatusMessage, color = StatusGreen)
                }
            }
        }
    }
}

@Composable
private fun DashboardSection(
    socialAccounts: List<SocialAccountEntity>
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // High Level Metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "Combined Followers",
                    value = "939.8K",
                    subtitle = "Across 7 Transmitters",
                    icon = Icons.Default.Groups,
                    color = NebulaPurple,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "30-Day Total Reach",
                    value = "6.48M",
                    subtitle = "+34.2% Growth",
                    icon = Icons.Default.Public,
                    color = CosmicCyan,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "Avg. Engagement",
                    value = "10.4%",
                    subtitle = "High Conversion",
                    icon = Icons.Default.ThumbUp,
                    color = StarGold,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Connected Transmitters",
                    value = "${socialAccounts.count { it.isConnected }}/7",
                    subtitle = "Active Channel Sync",
                    icon = Icons.Default.CellTower,
                    color = StatusGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Platform Health Breakdown
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Orbit Transmitters Status Overview", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    HorizontalDivider(color = StudioBorder)

                    socialAccounts.forEach { acc ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (acc.isConnected) StatusGreen else StatusRed)
                                )
                                Column {
                                    Text(acc.platform, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    Text(acc.accountHandle, fontSize = 11.sp, color = TextSecondary)
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("${acc.followerCount} Followers", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CosmicCyan)
                                Text("Reach: ${acc.reachCount}", fontSize = 10.sp, color = TextMuted)
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

@Composable
private fun AccountsManagementSection(
    allPlatforms: List<String>,
    connectedAccounts: List<SocialAccountEntity>,
    onToggleConnection: (SocialAccountEntity) -> Unit,
    onSaveOAuth: (platform: String, handle: String, token: String, refreshToken: String) -> Unit
) {
    var selectedOAuthPlatform by remember { mutableStateOf<String?>(null) }
    var selectedPlatformFilter by remember { mutableStateOf("All") }
    var showPermissionsDialogForAccount by remember { mutableStateOf<SocialAccountEntity?>(null) }

    val filteredAccounts = if (selectedPlatformFilter == "All") {
        connectedAccounts
    } else {
        connectedAccounts.filter { it.platform.equals(selectedPlatformFilter, ignoreCase = true) }
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Platform Filter Header & Quick Connect
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Connected OAuth Accounts (${connectedAccounts.size})", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("Multi-Account Enabled", fontSize = 10.sp, color = CosmicCyan, fontWeight = FontWeight.Bold)
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = selectedPlatformFilter == "All",
                                onClick = { selectedPlatformFilter = "All" },
                                label = { Text("All Platforms") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PurpleContainer,
                                    selectedLabelColor = OnPurpleContainer
                                )
                            )
                        }
                        items(allPlatforms) { platform ->
                            val count = connectedAccounts.count { it.platform.equals(platform, ignoreCase = true) }
                            FilterChip(
                                selected = selectedPlatformFilter == platform,
                                onClick = { selectedPlatformFilter = platform },
                                label = { Text("$platform ($count)") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PurpleContainer,
                                    selectedLabelColor = OnPurpleContainer
                                )
                            )
                        }
                    }
                }
            }
        }

        // Account Items
        if (filteredAccounts.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = StudioDarkSurface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.VpnKey, contentDescription = null, tint = CosmicCyan, modifier = Modifier.size(32.dp))
                        Text("No Connected Accounts Found", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Tap 'OAuth Login' on any platform to authorize a channel.", color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        } else {
            items(filteredAccounts) { account ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("account_card_${account.platform}_${account.id}"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (account.isActiveTarget) CosmicCyan else StudioBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (account.isConnected) PurpleContainer else StudioDarkSurfaceVariant,
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = when (account.platform) {
                                                "YouTube" -> Icons.Default.SmartDisplay
                                                "TikTok" -> Icons.Default.MusicNote
                                                "Instagram" -> Icons.Default.CameraAlt
                                                "Facebook" -> Icons.Default.Share
                                                "Threads" -> Icons.Default.AlternateEmail
                                                "Pinterest" -> Icons.Default.PushPin
                                                else -> Icons.Default.Tag
                                            },
                                            contentDescription = null,
                                            tint = if (account.isConnected) CosmicCyan else TextMuted
                                        )
                                    }
                                }

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(text = account.platform, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                        if (account.isActiveTarget) {
                                            Surface(shape = CircleShape, color = StatusGreen.copy(alpha = 0.2f)) {
                                                Text("Active Target", fontSize = 9.sp, color = StatusGreen, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                    Text(
                                        text = "${account.accountHandle} • ${account.followerCount} Followers",
                                        fontSize = 11.sp,
                                        color = CosmicCyan
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    if (account.isConnected) {
                                        onToggleConnection(account)
                                    } else {
                                        selectedOAuthPlatform = account.platform
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (account.isConnected) StatusRed.copy(alpha = 0.2f) else NebulaPurple
                                )
                            ) {
                                Icon(
                                    imageVector = if (account.isConnected) Icons.Default.LinkOff else Icons.Default.Lock,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = if (account.isConnected) StatusRed else Color.White
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (account.isConnected) "Disconnect" else "OAuth Login",
                                    color = if (account.isConnected) StatusRed else Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        // Permissions & Status Chips Row
                        HorizontalDivider(color = StudioBorder)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Surface(shape = RoundedCornerShape(6.dp), color = StudioDarkSurfaceVariant) {
                                    Text("Publish: ${if (account.hasPublishingPermission) "✓" else "✗"}", fontSize = 10.sp, color = if (account.hasPublishingPermission) StatusGreen else StatusRed, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                                Surface(shape = RoundedCornerShape(6.dp), color = StudioDarkSurfaceVariant) {
                                    Text("Schedule: ${if (account.hasSchedulingPermission) "✓" else "✗"}", fontSize = 10.sp, color = if (account.hasSchedulingPermission) StatusGreen else StatusRed, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                                Surface(shape = RoundedCornerShape(6.dp), color = StudioDarkSurfaceVariant) {
                                    Text("Analytics: ${if (account.hasAnalyticsPermission) "✓" else "✗"}", fontSize = 10.sp, color = if (account.hasAnalyticsPermission) StatusGreen else StatusRed, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }

                            TextButton(onClick = { showPermissionsDialogForAccount = account }) {
                                Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(14.dp), tint = CosmicCyan)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Permissions", fontSize = 11.sp, color = CosmicCyan)
                            }
                        }
                    }
                }
            }
        }

        // Add Account Button for Any Supported Platform
        item {
            Button(
                onClick = { selectedOAuthPlatform = "YouTube" },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NebulaPurple)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Connect Additional Account via OAuth", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        item { Spacer(modifier = Modifier.height(20.dp)) }
    }

    selectedOAuthPlatform?.let { platform ->
        OAuthAuthorizationDialog(
            platform = platform,
            onDismiss = { selectedOAuthPlatform = null },
            onAuthorizeSuccess = { handle, token, refreshToken ->
                onSaveOAuth(platform, handle, token, refreshToken)
                selectedOAuthPlatform = null
            }
        )
    }

    showPermissionsDialogForAccount?.let { acc ->
        AlertDialog(
            onDismissRequest = { showPermissionsDialogForAccount = null },
            title = { Text("Account Permissions Overview", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Granted OAuth scopes for ${acc.accountHandle} on ${acc.platform}:", fontSize = 12.sp, color = TextSecondary)
                    Text("• ${acc.oauthScopes}", fontSize = 11.sp, color = StarGold, fontWeight = FontWeight.Bold)
                    HorizontalDivider(color = StudioBorder)
                    Text("✓ Automated Content Publishing", fontSize = 12.sp, color = StatusGreen)
                    Text("✓ Scheduled Broadcast Queuing", fontSize = 12.sp, color = StatusGreen)
                    Text("✓ Realtime Analytics & Reach Telemetry", fontSize = 12.sp, color = StatusGreen)
                }
            },
            confirmButton = {
                Button(onClick = { showPermissionsDialogForAccount = null }, colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan)) {
                    Text("Close", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = StudioDarkSurface
        )
    }
}

@Composable
fun OAuthAuthorizationDialog(
    platform: String,
    onDismiss: () -> Unit,
    onAuthorizeSuccess: (handle: String, token: String, refreshToken: String) -> Unit
) {
    var accountHandleInput by remember { mutableStateOf("@${platform.lowercase()}_creator_2026") }
    var oauthStep by remember { mutableIntStateOf(1) } // 1 = Review Scopes, 2 = Authorize, 3 = Complete
    var isSimulatingAuth by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.VpnKey, contentDescription = null, tint = CosmicCyan)
                Text("OAuth 2.0 Login — $platform", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = StudioDarkSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Requested Permissions & Scopes:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StarGold)
                        Text("• Read channel profile & follower metrics", fontSize = 11.sp, color = TextSecondary)
                        Text("• Automated video/media upload & publishing", fontSize = 11.sp, color = TextSecondary)
                        Text("• Encrypted token storage (AES-256)", fontSize = 11.sp, color = StatusGreen, fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedTextField(
                    value = accountHandleInput,
                    onValueChange = { accountHandleInput = it },
                    label = { Text("Account Handle / Username") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = StudioDarkSurface,
                        unfocusedContainerColor = StudioDarkSurface
                    )
                )

                if (isSimulatingAuth) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(color = CosmicCyan, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Exchanging Authorization Code...", fontSize = 12.sp, color = CosmicCyan)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    isSimulatingAuth = true
                    val fakeAccess = "oauth_access_tok_${platform.lowercase()}_${System.currentTimeMillis()}"
                    val fakeRefresh = "oauth_ref_${platform.lowercase()}_${System.currentTimeMillis()}"
                    onAuthorizeSuccess(accountHandleInput, fakeAccess, fakeRefresh)
                },
                enabled = !isSimulatingAuth && accountHandleInput.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StudioDarkBackground)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Authorize & Connect", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        },
        containerColor = StudioDarkSurface
    )
}

@Composable
private fun BulkPublishingSection(
    connectedAccounts: List<SocialAccountEntity>,
    onPublishTriggered: (String) -> Unit
) {
    val selectedPlatforms = remember { mutableStateListOf<String>().apply { addAll(connectedAccounts.map { it.platform }) } }
    var bulkMessageInput by remember { mutableStateOf("") }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Cross-Platform Multi-Transmitter Broadcast", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = NebulaPurple)
                    HorizontalDivider(color = StudioBorder)

                    Text("1. Target Transmitter Channels:", fontSize = 12.sp, color = TextSecondary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(connectedAccounts) { acc ->
                            val isChecked = selectedPlatforms.contains(acc.platform)
                            FilterChip(
                                selected = isChecked,
                                onClick = {
                                    if (isChecked) selectedPlatforms.remove(acc.platform)
                                    else selectedPlatforms.add(acc.platform)
                                },
                                leadingIcon = {
                                    if (isChecked) Icon(Icons.Default.Check, contentDescription = null, tint = OnPurpleContainer, modifier = Modifier.size(16.dp))
                                },
                                label = { Text(acc.platform) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PurpleContainer,
                                    selectedLabelColor = OnPurpleContainer
                                )
                            )
                        }
                    }

                    Text("2. Broadcast Payload Content:", fontSize = 12.sp, color = TextSecondary)
                    OutlinedTextField(
                        value = bulkMessageInput,
                        onValueChange = { bulkMessageInput = it },
                        placeholder = { Text("Enter post text or viral announcement to post to all selected channels...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = StudioDarkSurfaceVariant,
                            unfocusedContainerColor = StudioDarkSurfaceVariant,
                            focusedBorderColor = CosmicCyan,
                            unfocusedBorderColor = StudioBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Button(
                        onClick = {
                            if (bulkMessageInput.isNotBlank()) {
                                onPublishTriggered("Bulk Broadcast initiated across ${selectedPlatforms.size} platforms!")
                                bulkMessageInput = ""
                            }
                        },
                        enabled = bulkMessageInput.isNotBlank() && selectedPlatforms.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, tint = StudioDarkBackground)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Broadcast To Selected Channels", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SocialInboxSection(
    selectedFilter: String,
    onFilterChange: (String) -> Unit,
    replyText: String,
    onReplyTextChange: (String) -> Unit,
    onSendReply: () -> Unit
) {
    val sampleInboxItems = listOf(
        InboxItem("1", "TikTok", "@tech_lover22", "Comment", "Which AI tool did you use for the 3D voiceover?", "10m ago"),
        InboxItem("2", "YouTube", "SciFi Explorer", "Comment", "Mind blown! Subscribed to the channel immediately.", "25m ago"),
        InboxItem("3", "Instagram", "@creator_pro", "Message", "Hey! Loved your faceless reels. Are you open to a channel collab?", "1h ago"),
        InboxItem("4", "X", "@space_geek", "Notification", "Retweeted your post on Quantum Computing 2026", "2h ago")
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Comments", "Messages", "Notifications").forEach { filter ->
                    val isSelected = selectedFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { onFilterChange(filter) },
                        label = { Text(filter) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PurpleContainer,
                            selectedLabelColor = OnPurpleContainer
                        )
                    )
                }
            }
        }

        items(sampleInboxItems) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CyanContainer
                        ) {
                            Text(
                                text = "${item.platform} • ${item.type}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = OnCyanContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }

                        Text(item.timeAgo, fontSize = 10.sp, color = TextMuted)
                    }

                    Text(item.author, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(item.body, fontSize = 12.sp, color = TextSecondary)

                    // Reply Interface
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = replyText,
                            onValueChange = onReplyTextChange,
                            placeholder = { Text("Send quick reply...", fontSize = 11.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = StudioDarkSurfaceVariant,
                                unfocusedContainerColor = StudioDarkSurfaceVariant
                            )
                        )
                        IconButton(
                            onClick = onSendReply,
                            modifier = Modifier.background(NebulaPurple, CircleShape)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

private data class InboxItem(
    val id: String,
    val platform: String,
    val author: String,
    val type: String,
    val body: String,
    val timeAgo: String
)

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimary)
            Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
            Text(subtitle, fontSize = 10.sp, color = TextMuted)
        }
    }
}
