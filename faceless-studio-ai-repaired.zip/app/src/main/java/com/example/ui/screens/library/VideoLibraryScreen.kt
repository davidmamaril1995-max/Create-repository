package com.example.ui.screens.library

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.ProjectEntity
import com.example.ui.theme.*
import com.example.ui.viewmodels.FacelessViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoLibraryScreen(
    viewModel: FacelessViewModel,
    onNavigateToCreate: () -> Unit
) {
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    var isGridView by remember { mutableStateOf(true) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") } // All, Published, Ready, Scheduled, Favorites
    var sortBy by remember { mutableStateOf("Date") } // Date, Title, Duration, Views

    var selectedVideoForPlayer by remember { mutableStateOf<ProjectEntity?>(null) }
    var selectedVideoForExport by remember { mutableStateOf<ProjectEntity?>(null) }
    var snackbarMessage by remember { mutableStateOf("") }

    var isStorageDashboardExpanded by remember { mutableStateOf(false) }
    var isAutoCleanupDialogOpen by remember { mutableStateOf(false) }
    var isMultiSelectMode by remember { mutableStateOf(false) }
    val selectedProjectIds = remember { mutableStateListOf<Long>() }

    // Filtering & Sorting
    val filteredProjects = projects.filter { project ->
        val matchesSearch = project.title.contains(searchQuery, ignoreCase = true) ||
                project.nicheCategory.contains(searchQuery, ignoreCase = true) ||
                project.scriptBody.contains(searchQuery, ignoreCase = true)

        val matchesFilter = when (selectedFilter) {
            "Published" -> project.status.equals("Published", ignoreCase = true)
            "Ready" -> project.status.equals("Ready", ignoreCase = true)
            "Scheduled" -> project.status.equals("Scheduled", ignoreCase = true)
            "Favorites" -> project.isFavorite
            else -> true
        }
        matchesSearch && matchesFilter
    }.sortedWith { a, b ->
        when (sortBy) {
            "Title" -> a.title.compareTo(b.title, ignoreCase = true)
            "Duration" -> b.durationSeconds.compareTo(a.durationSeconds)
            "Views" -> b.viewsCount.compareTo(a.viewsCount)
            else -> b.updatedAt.compareTo(a.updatedAt)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = CosmicCyan, modifier = Modifier.size(24.dp))
                        Text(
                            text = "Galactic Video Library",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { isGridView = !isGridView }) {
                        Icon(
                            imageVector = if (isGridView) Icons.Default.List else Icons.Default.GridView,
                            contentDescription = "Toggle View Mode",
                            tint = CosmicCyan
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBackground)
            )
        },
        containerColor = StudioDarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Storage Management Dashboard Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.SdStorage, contentDescription = null, tint = StarGold, modifier = Modifier.size(20.dp))
                            val totalMB = projects.sumOf { (it.durationSeconds * 2.2).toInt() }
                            Text("Video Storage Manager ($totalMB MB / 64.0 GB)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }

                        IconButton(onClick = { isStorageDashboardExpanded = !isStorageDashboardExpanded }) {
                            Icon(
                                imageVector = if (isStorageDashboardExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = CosmicCyan
                            )
                        }
                    }

                    LinearProgressIndicator(
                        progress = { ((projects.size * 45) / 1000f).coerceIn(0.02f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape),
                        color = StarGold,
                        trackColor = StudioDarkSurfaceVariant
                    )

                    if (isStorageDashboardExpanded) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { isMultiSelectMode = !isMultiSelectMode },
                                colors = ButtonDefaults.buttonColors(containerColor = if (isMultiSelectMode) PurpleContainer else StudioDarkSurfaceVariant),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isMultiSelectMode) "Done Selecting" else "Multi-Select", fontSize = 11.sp, color = TextPrimary)
                            }

                            if (isMultiSelectMode && selectedProjectIds.isNotEmpty()) {
                                Button(
                                    onClick = {
                                        viewModel.deleteSelectedProjects(selectedProjectIds.toList())
                                        selectedProjectIds.clear()
                                        snackbarMessage = "Selected videos permanently deleted."
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusRed),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Delete (${selectedProjectIds.size})", fontSize = 11.sp, color = Color.White)
                                }
                            }

                            Button(
                                onClick = { isAutoCleanupDialogOpen = true },
                                colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Auto Cleanup", fontSize = 11.sp, color = StudioDarkBackground, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Search Bar & Sort Dropdown Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search video titles, scripts...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("video_library_search"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = StudioDarkSurface,
                        unfocusedContainerColor = StudioDarkSurface,
                        focusedBorderColor = CosmicCyan,
                        unfocusedBorderColor = StudioBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                // Sort Chip Toggle
                FilterChip(
                    selected = true,
                    onClick = {
                        sortBy = when (sortBy) {
                            "Date" -> "Title"
                            "Title" -> "Duration"
                            "Duration" -> "Views"
                            else -> "Date"
                        }
                    },
                    label = { Text("Sort: $sortBy", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Sort, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PurpleContainer,
                        selectedLabelColor = OnPurpleContainer
                    )
                )
            }

            // Category Filter Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All", "Published", "Ready", "Scheduled", "Favorites").forEach { filter ->
                    val isSelected = selectedFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedFilter = filter },
                        label = {
                            Text(
                                text = filter,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) OnCyanContainer else TextSecondary
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanContainer,
                            containerColor = StudioDarkSurface
                        )
                    )
                }
            }

            // Video Library Content (Grid or List)
            if (filteredProjects.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.VideoCall, contentDescription = null, tint = TextMuted, modifier = Modifier.size(56.dp))
                        Text("No video assets found in Library", color = TextSecondary, fontSize = 15.sp)
                        Button(
                            onClick = onNavigateToCreate,
                            colors = ButtonDefaults.buttonColors(containerColor = NebulaPurple)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Create New Video Asset", color = Color.White)
                        }
                    }
                }
            } else {
                if (isGridView) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                    ) {
                        items(filteredProjects) { project ->
                            VideoGridCard(
                                project = project,
                                onPlay = { selectedVideoForPlayer = project },
                                onFavoriteToggle = { viewModel.toggleFavorite(project.id, !project.isFavorite) },
                                onDuplicate = {
                                    viewModel.duplicateProject(project)
                                    snackbarMessage = "Duplicated: ${project.title}"
                                },
                                onExport = { selectedVideoForExport = project },
                                onDelete = { viewModel.deleteProject(project.id) },
                                onPublish = { viewModel.publishProjectNow(project) }
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                    ) {
                        items(filteredProjects) { project ->
                            VideoListCard(
                                project = project,
                                onPlay = { selectedVideoForPlayer = project },
                                onFavoriteToggle = { viewModel.toggleFavorite(project.id, !project.isFavorite) },
                                onDuplicate = {
                                    viewModel.duplicateProject(project)
                                    snackbarMessage = "Duplicated: ${project.title}"
                                },
                                onExport = { selectedVideoForExport = project },
                                onDelete = { viewModel.deleteProject(project.id) },
                                onPublish = { viewModel.publishProjectNow(project) }
                            )
                        }
                    }
                }
            }

            if (snackbarMessage.isNotEmpty()) {
                Snackbar(
                    action = {
                        TextButton(onClick = { snackbarMessage = "" }) {
                            Text("OK", color = CosmicCyan)
                        }
                    },
                    containerColor = StudioDarkSurface
                ) {
                    Text(snackbarMessage, color = TextPrimary)
                }
            }
        }
    }

    // Interactive Built-in Video Player Modal
    selectedVideoForPlayer?.let { project ->
        BuiltInVideoPlayerDialog(
            project = project,
            onDismiss = { selectedVideoForPlayer = null }
        )
    }

    // Export Dialog
    selectedVideoForExport?.let { project ->
        ExportModalDialog(
            project = project,
            onDismiss = { selectedVideoForExport = null },
            onExportRetentionConfirm = { retentionChoice ->
                viewModel.handleExportRetention(project, retentionChoice)
                snackbarMessage = "Export action applied: $retentionChoice"
            }
        )
    }

    if (isAutoCleanupDialogOpen) {
        AutoCleanupDialog(
            onDismiss = { isAutoCleanupDialogOpen = false },
            onRunCleanup = { days, clearCache ->
                viewModel.performAutoCleanup(days, clearCache)
                snackbarMessage = "Auto-cleanup complete: Purged drafts older than $days days."
                isAutoCleanupDialogOpen = false
            }
        )
    }
}

@Composable
private fun VideoGridCard(
    project: ProjectEntity,
    onPlay: () -> Unit,
    onFavoriteToggle: () -> Unit,
    onDuplicate: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit,
    onPublish: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("video_grid_card_${project.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Column {
            // Poster Preview Frame
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(NebulaPurpleDark, StudioDarkSurfaceVariant)
                        )
                    )
                    .clickable { onPlay() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayCircleFilled,
                    contentDescription = "Play",
                    tint = CosmicCyan,
                    modifier = Modifier.size(44.dp)
                )

                // Status Badge Top Left
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (project.status.lowercase()) {
                        "published" -> StatusGreen.copy(alpha = 0.85f)
                        "scheduled" -> StarGold.copy(alpha = 0.85f)
                        else -> NebulaPurple.copy(alpha = 0.85f)
                    },
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                ) {
                    Text(
                        text = project.status,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                // Favorite Button Top Right
                IconButton(
                    onClick = onFavoriteToggle,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                ) {
                    Icon(
                        imageVector = if (project.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Favorite",
                        tint = if (project.isFavorite) StarGold else Color.White
                    )
                }

                // Duration Badge Bottom Right
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.7f),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                ) {
                    Text(
                        text = "${project.durationSeconds}s • ${project.videoFormat}",
                        fontSize = 9.sp,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Info Body
            Column(
                modifier = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = project.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(project.createdAt)),
                    fontSize = 10.sp,
                    color = TextMuted
                )

                // Actions Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        IconButton(onClick = onDuplicate, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", tint = TextSecondary, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = onExport, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Download, contentDescription = "Export", tint = CosmicCyan, modifier = Modifier.size(16.dp))
                        }
                    }

                    IconButton(onClick = onPublish, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Send, contentDescription = "Publish", tint = NebulaPurpleLight, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoListCard(
    project: ProjectEntity,
    onPlay: () -> Unit,
    onFavoriteToggle: () -> Unit,
    onDuplicate: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit,
    onPublish: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("video_list_card_${project.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Poster Box
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.verticalGradient(listOf(NebulaPurpleDark, StudioDarkSurfaceVariant))
                    )
                    .clickable { onPlay() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayCircle,
                    contentDescription = null,
                    tint = CosmicCyan,
                    modifier = Modifier.size(36.dp)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = project.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = "${project.nicheCategory} • ${project.contentType} • ${project.durationSeconds}s",
                    fontSize = 11.sp,
                    color = TextSecondary
                )

                Text(
                    text = "Created: ${SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(project.createdAt))}",
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(onClick = onFavoriteToggle, modifier = Modifier.size(28.dp)) {
                    Icon(
                        imageVector = if (project.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Favorite",
                        tint = if (project.isFavorite) StarGold else TextMuted
                    )
                }

                Row {
                    IconButton(onClick = onExport, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Download, contentDescription = "Export", tint = CosmicCyan, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onPublish, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Send, contentDescription = "Publish", tint = NebulaPurple, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun BuiltInVideoPlayerDialog(
    project: ProjectEntity,
    onDismiss: () -> Unit
) {
    var isPlaying by remember { mutableStateOf(true) }
    var currentProgress by remember { mutableFloatStateOf(0.35f) }
    var isMuted by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.SmartDisplay, contentDescription = null, tint = CosmicCyan)
                Text(project.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Interactive Video Player Viewport Simulation
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF0D0B1E), NebulaPurpleDark, StudioDarkSurfaceVariant)
                            )
                        )
                        .border(1.dp, StudioBorder, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = CosmicCyan.copy(alpha = 0.2f),
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                IconButton(onClick = { isPlaying = !isPlaying }) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = CosmicCyan,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = "[NARRATION VOICE]: ${project.hookText}",
                            fontSize = 11.sp,
                            color = StarGold,
                            fontWeight = FontWeight.Medium
                        )

                        Text(
                            text = project.scriptBody.take(100) + "...",
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }

                    // On-screen Audio/Video Quality Tag
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color.Black.copy(alpha = 0.6f),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "1080p 60fps • AI Synthesized",
                            fontSize = 9.sp,
                            color = StatusGreen,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                // Scrub Bar Controls
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Slider(
                        value = currentProgress,
                        onValueChange = { currentProgress = it },
                        colors = SliderDefaults.colors(
                            thumbColor = CosmicCyan,
                            activeTrackColor = CosmicCyan,
                            inactiveTrackColor = StudioDarkSurfaceVariant
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("00:15", fontSize = 10.sp, color = TextMuted)
                        Text("00:${project.durationSeconds}", fontSize = 10.sp, color = TextMuted)
                    }
                }

                // Volume & Fullscreen Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { isMuted = !isMuted }) {
                            Icon(
                                imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                contentDescription = "Mute",
                                tint = TextSecondary
                            )
                        }
                        Text(if (isMuted) "Muted" else "Voice: ${project.voiceoverStyle}", fontSize = 11.sp, color = TextSecondary)
                    }

                    Text("Format: ${project.videoFormat}", fontSize = 11.sp, color = NebulaPurpleLight, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = NebulaPurple)
            ) {
                Text("Close Player", color = Color.White)
            }
        },
        containerColor = StudioDarkSurface
    )
}

@Composable
fun ExportModalDialog(
    project: ProjectEntity,
    onDismiss: () -> Unit,
    onExportRetentionConfirm: (String) -> Unit = {}
) {
    var selectedResolution by remember { mutableStateOf("1080p (Full HD 60fps)") }
    var selectedRetentionOption by remember { mutableStateOf("Keep file on device") }
    var exportStatus by remember { mutableStateOf("") }
    var isExportDone by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Export & Storage Control", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("1. Select Render Resolution:", fontSize = 12.sp, color = TextSecondary)

                listOf("1080p (Full HD 60fps)", "4K Quantum Sci-Fi Ultra", "720p Mobile Quick").forEach { res ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedResolution = res },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedResolution == res,
                            onClick = { selectedResolution = res },
                            colors = RadioButtonDefaults.colors(selectedColor = CosmicCyan)
                        )
                        Text(res, fontSize = 13.sp, color = TextPrimary)
                    }
                }

                HorizontalDivider(color = StudioBorder)

                Text("2. Post-Export Media Retention Action:", fontSize = 12.sp, color = StarGold, fontWeight = FontWeight.Bold)

                listOf(
                    "Keep file on device",
                    "Delete after upload",
                    "Move to cloud storage",
                    "Archive project only"
                ).forEach { opt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedRetentionOption = opt },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedRetentionOption == opt,
                            onClick = { selectedRetentionOption = opt },
                            colors = RadioButtonDefaults.colors(selectedColor = StarGold)
                        )
                        Text(opt, fontSize = 12.sp, color = TextPrimary)
                    }
                }

                if (exportStatus.isNotEmpty()) {
                    Text(exportStatus, fontSize = 11.sp, color = StatusGreen, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    exportStatus = "✓ Export complete ($selectedResolution)! Saved to /Download/Intergalactic_${project.id}.mp4"
                    isExportDone = true
                    onExportRetentionConfirm(selectedRetentionOption)
                },
                colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan)
            ) {
                Icon(Icons.Default.Download, contentDescription = null, tint = StudioDarkBackground)
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isExportDone) "Processed ($selectedRetentionOption)" else "Render & Export MP4", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Done", color = TextSecondary)
            }
        },
        containerColor = StudioDarkSurface
    )
}

@Composable
fun AutoCleanupDialog(
    onDismiss: () -> Unit,
    onRunCleanup: (draftsAgeDays: Int, clearCache: Boolean) -> Unit
) {
    var selectedDays by remember { mutableIntStateOf(14) }
    var clearCacheChecked by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Auto Cleanup Storage Rules", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Automate old draft and temporary render purging:", fontSize = 12.sp, color = TextSecondary)

                Text("1. Delete Drafts Older Than:", fontSize = 12.sp, color = StarGold, fontWeight = FontWeight.Bold)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(7, 14, 30).forEach { days ->
                        FilterChip(
                            selected = selectedDays == days,
                            onClick = { selectedDays = days },
                            label = { Text("$days Days") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyanContainer,
                                selectedLabelColor = OnCyanContainer
                            )
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { clearCacheChecked = !clearCacheChecked },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = clearCacheChecked,
                        onCheckedChange = { clearCacheChecked = it },
                        colors = CheckboxDefaults.colors(checkedColor = CosmicCyan)
                    )
                    Text("Clear cached video previews & temp renders", fontSize = 12.sp, color = TextPrimary)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onRunCleanup(selectedDays, clearCacheChecked) },
                colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan)
            ) {
                Icon(Icons.Default.CleaningServices, contentDescription = null, tint = StudioDarkBackground)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Run Auto-Purge Now", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        },
        containerColor = StudioDarkSurface
    )
}
