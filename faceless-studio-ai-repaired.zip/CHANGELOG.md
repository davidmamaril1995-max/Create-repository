## [1.1.1] - 2026-07-24 - Media Studio Wiring & Debug Build Repair

### Fixed
- **Media Import Studio reachability**: `MediaStudioScreen` (image/video upload, editing toolkit, subtitle/caption generation, AI Recreate) was fully built but unreachable — not registered in navigation and not linked from any screen. Added a `MediaStudio` route, registered it in the `NavHost`, and added a Home screen entry point.
- **Real media upload**: Media Studio's upload flow now uses the Android system picker (`ActivityResultContracts.GetContent()`) and resolves real file names via `ContentResolver`, instead of simulating a hardcoded filename. Tool actions now require a real uploaded file.
- **Debug build signing failure**: `debugConfig` signing config pointed at a `debug.keystore` file that was never committed and never generated, breaking every debug build (local and CI). Added an automatic `keytool`-based keystore generation task so the build always has a valid debug keystore.

## [1.1.0] - 2026-07-23 - Phase 5 Production Release

### Added
- **Production-Ready Social Media OAuth System**:
  - Implemented OAuth 2.0 authentication architecture supporting YouTube (Google OAuth), TikTok, Facebook, Instagram, Threads, Pinterest, and X (Twitter).
  - Created `OAuthManager` for OAuth authorization code simulation, access token exchange, and refresh token rotation.
  - Created `TokenManager` for Base64 encrypted token storage, validity checks, and expiration handling.
  - Created `SessionManager` for persistent multi-account session recovery across application launches.
  - Created `SocialAccountRepository` for multi-account Room database persistence, active account targeting, and permissions management.
  - Created `SocialAuthViewModel` for reactive OAuth UI states, permissions toggling, and publishing history logs.
- **Multi-Account Per Platform Support**:
  - Upgraded `SocialAccountEntity` with primary key auto-generation, enabling users to connect and manage multiple channels per platform (e.g. YouTube Channel A, Channel B).
  - Added account switching controls to select active publishing targets per platform.
- **Enhanced Social Command Center**:
  - Integrated OAuth Login Modal for manual-key-free connection flows.
  - Added permissions breakdown (Publishing Access, Scheduling Access, Analytics Access) with scope overview dialog.
  - Integrated publishing history logs and cross-platform multi-channel broadcast publishing.
- **Automated GitHub Actions Integration**:
  - Configured `.github/workflows/android-build.yml` for automatic Gradle build execution (`gradle assembleDebug`) and downloadable APK artifact uploading (`IntergalacticStudio-APK`).

### Changed
- Incremented Room Database version to 4 with schema migration support.
- Updated `SocialAccountDao` with multi-account queries, active target setters, and token refresh queries.
- Removed manual API key entry requirements for social platforms in favor of OAuth token authorization.


### Added
- **Core Architecture**:
  - Implemented modern MVVM + Repository pattern with Room database local caching and Flow reactivity.
  - Room database entities for `ProjectEntity`, `TrendTopicEntity`, and `SocialAccountEntity`.
  - Full REST client integration for Gemini API (`gemini-3.5-flash`) via OkHttp & Retrofit with custom network timeouts.
- **UI & Navigation**:
  - Integrated 6-tab Jetpack Compose Navigation hierarchy: Home, Trending, Create, Projects, Analytics, Settings.
  - Implemented Material 3 dark studio theme with edge-to-edge support and gesture navigation inset handling.
  - Added custom adaptive app launcher icon (`ic_launcher`) with custom foreground and background layers.
- **Modules & Features**:
  - **Trend Discovery Engine**: Real-time topic virality scoring, category filtering, search, and instant script trigger.
  - **AI Script & Hook Generator**: Generates 3 viral hooks, voiceover body script, and call-to-action (CTA).
  - **Voiceover & Video Production**: Aspect ratio options (9:16 Shorts/Reels vs 16:9 Landscape), voiceover style selection, and visual style preferences.
  - **Multi-Platform Publishing**: Direct scheduling and simulated auto-publishing to YouTube, TikTok, Threads, Pinterest, Facebook, and Instagram.
  - **Analytics Dashboard**: Organic views tracking, engagement rates, platform distribution breakdown, and top-performing content list.
  - **Studio Settings**: AI credentials status, social account connection toggles, theme preferences, and local data backup.

### Changed
- Configured Application ID to `com.aistudio.facelessstudioai.app`.
- Updated app name string resource and project settings to "Faceless Studio AI".
- Configured Gradle dependencies for Compose Navigation, Room KSP, Datastore, and Coil.
